﻿using Product_Crud_ebAPI.Models;

namespace Product_Crud_ebAPI.Repository
{
    public interface IProductRepository
    {
        IEnumerable<Product> GetAll();
        Product GetById(int id);
        void Add(Product product);
        void Update(Product product);
        void Delete(int id);
    }
}
