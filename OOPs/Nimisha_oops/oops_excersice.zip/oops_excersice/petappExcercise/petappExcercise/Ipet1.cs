﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace petappExcercise
{
    public interface Ipet1
    {
        public void addpet();
        public void Listpet();
        public void SetFavoritePet();

        public void RemoveFromFavorites();



    }
}
